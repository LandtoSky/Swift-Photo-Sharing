//
//  ArtworkTagCell.swift
//  artmonious
//
//  Created by Admin on 13/09/1437 AH.
//  Copyright © 1437 AH Victor. All rights reserved.
//

import Foundation
import UIKit

class ArtworkTagCell: UICollectionViewCell {
    
    @IBOutlet weak var btn_cell1: UIButton!
    @IBOutlet weak var imageview: UIImageView!
    
    
    
}