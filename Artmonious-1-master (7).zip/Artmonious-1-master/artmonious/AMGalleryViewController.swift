
//
//  AMGalleryViewController.swift
//  artmonious
//
//  Created by Admin on 17/09/1437 AH.
//  Copyright © 1437 AH Victor. All rights reserved.
//

import Foundation
import UIKit

class AMGalleryViewControlelr: UIViewController {
    @IBOutlet weak var item1: UITabBarItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
}