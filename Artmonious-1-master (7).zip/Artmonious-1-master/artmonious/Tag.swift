//
//  Tag.swift
//  artmonious
//
//  Created by Admin on 11/09/1437 AH.
//  Copyright © 1437 AH Victor. All rights reserved.
//

import Foundation

class Tag {
    
    var name: String?
    var selected = false
}
